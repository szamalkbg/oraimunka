import java.util.Random;

public class Feladat2 {
    public static void main(String[] args) {
        // Tömb méretének meghatározása (például  10 helyre)
        int tombMerete =  10;
        
        // Tömbben tárolt számok típusának definiálása
        int[] tomb = new int[tombMerete];
        
        // Random objektum létrehozása a számok generálásához
        Random random = new Random();
        
        // A tömb feltöltése  2 jegyű páratlan számokkal
        for (int i =  0; i < tombMerete; i++) {
            //  10 és  99 közötti véletlen szám generálása
            int szam =  10 + random.nextInt(90);
            
            // Ellenőrzés, hogy a szám páratlan-e
            if (szam %  2 !=  0) {
                tomb[i] = szam;
            } else {
                // Ha a szám páros, újra generáljuk
                i--; // csökkentjük az indexet, hogy újra próbálkozhassunk
            }
        }
        
        // Tömb tartalmának kiírása
        for (int szam : tomb) {
            System.out.println(szam);
        }
    }
}
