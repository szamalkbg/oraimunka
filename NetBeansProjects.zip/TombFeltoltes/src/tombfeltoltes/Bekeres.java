/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tombfeltoltes;
import java.util.Scanner;
       
static Scanner sc = new Scanner(System.in, "latin");
public class Bekeres {

    public static void main(String[] args) {
        final int DB = 3;
        String[] nevek = new String[3];
        for (int i = 0; i < DB; i++) {
            System.out.println("név: ",i+1);
            String nev = sc.nextLine();
            nevek[i] = nev;
        }
        
//        kiírás
        System.out.println("Bekért nevek:");
        for (int i = 0; i < DB; i++) {
            System.out.println(nevek[i]);
    }
}