package veletlenszamok;

public class VeletlenSzamok {

    public static void main(String[] args) {
        final int DB = 5;
        int[] korok = new int[DB];
        
        
        for (int i = 0; i < DB; i++) {
            korok[i] = rnd.nextInt();
        }
        
        for (int i = 0; i < DB; i++) {
            System.out.println(korok[i]);
        }
        
        String[] betuk = {"a", "b", "c", "d", "e"};
        System.out.println("3 db betű (a..e):");
        for (int i = 0; i < 3; i++) {
            int index = (int) (Math.random()*betuk.length);
            String betu = betuk[index];
            System.out.println(betu + " ");
    }
        System.out.println("");
    }
    int m = 0;
    for (int i = 1; i < db; i++) {
    if(letszamok[i] > letszamok[m]){
        m = i;
    }
    String helys = helysegek[m];
    int letsz = letszamok[m];
    System.out.println("%s rendelkezik a legtöbb lakossal");
    
    System.out.println("Van pont 1000 fős helység: ");
    int i = 0;
    while(i < N && ! (T)) {
        i++;
    }
    boolean van = i < N || i >= N;
    
    if (van = True) {
        
    }
}
}
