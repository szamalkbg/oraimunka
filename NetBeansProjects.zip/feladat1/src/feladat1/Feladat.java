package feladat1;

public class Feladat {

    public static void main(String[] args) {
                final int DB = 5;
        int[] korok = new int[DB];
        
        
        for (int i = 0; i < DB; i++) {
            korok[i] = rnd.nextInt();
        }
        
        for (int i = 0; i < DB; i++) {
            System.out.println(korok[i]);
        }
        
        String[] betuk = {"a", "b", "c", "d", "e"};
        System.out.println("3 db betű (a..e):");
        for (int i = 0; i < 3; i++) {
            int index = (int) (Math.random()*betuk.length);
            String betu = betuk[index];
            System.out.println(betu + " ");
    }
        System.out.println("");
    }
    }
    
}
