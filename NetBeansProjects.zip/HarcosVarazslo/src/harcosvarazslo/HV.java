package harcosvarazslo;

import java.util.Random;

public class HV {

    public static void main(String[] args) {
        Random r = new Random();
        StringBuilder s = new StringBuilder(10);
        for (int i =  0; i <  10; i++) {
            s.append("HV_X".charAt(r.nextInt(4)));
        }
        System.out.println(s.toString());
    }
}
