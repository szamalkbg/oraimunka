package magyarazat;

public class Magyarazat {

    public static void main(String[] args) {
        String eredeti = "abc.12x";
        
        String uj = eredeti.substring(1);
        uj = eredeti.substring(0);
        uj = eredeti.substring(1);
        uj = eredeti.substring(4);
        System.out.println(uj);
        
        uj = eredeti.substring(0, 3);
        System.out.println(uj);
        uj = eredeti.substring(4,6);
        System.out.println(uj);
        
        int hossz = eredeti.length();
        System.out.println("");
        
        boolean kezdAbc = eredeti.startsWith("abc");
        boolean vege2x = eredeti.startsWith("2x");
        boolean vanBennePont = eredeti.contains(".");
        System.out.println("abc-vel kezdődik: " + kezdAbc);
        
        
        String palya = "___";
        
    }
}
