/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javatombok;

/**
 *
 * @author BoldizsárGergely(SZO
 */
public class Javatombok {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //String[] nevek = {"Ede", "Pál" "Xénia"};
        //int[] korok = {22, 31, 19};

        final int TOMB_MERET = 3;//inicail
        String[] nevek;//deklarálás
        int[] korok;//deklarálás

        nevek = new String[TOMB_MERET];//inicializálás
        nevek[0] = "Ede";//értékadás
        nevek[1] = "Pál";//értékadás
        nevek[2] = "Xénia";//értékadás

        korok = new int[TOMB_MERET];
        korok[0] = 101;//értékadás
        korok[1] = 9;//értékadás
        korok[2] = 21;//értékadás
        
        
    }
}
